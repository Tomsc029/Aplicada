#!/usr/bin/env python3
# calculator.py
# Calculadora OOP avanzada con opción de regresar + cálculo de áreas (Punto 4)
# Autor: (tu nombre)
# Ejecutar: python3 calculator.py

# =======================
# CLASE CALCULADORA
# =======================
class Calculator:
    """Clase que implementa operaciones aritméticas básicas y avanzadas."""
    def __init__(self):
        self.last_result = 0  # Guarda el último resultado

    # --- Operaciones básicas ---
    def add(self, a, b):
        self.last_result = a + b
        return self.last_result

    def subtract(self, a, b):
        self.last_result = a - b
        return self.last_result

    def multiply(self, a, b):
        self.last_result = a * b
        return self.last_result

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Error: división por cero.")
        self.last_result = a / b
        return self.last_result

    # --- Operaciones avanzadas ---
    def power(self, base, exponent):
        """Calcula base^exponent sin usar pow() ni math."""
        result = 1
        if exponent >= 0:
            for _ in range(int(exponent)):
                result *= base
        else:
            for _ in range(abs(int(exponent))):
                result *= base
            result = 1 / result
        self.last_result = result
        return result

    def square_root(self, n):
        """Raíz cuadrada por método de Newton-Raphson."""
        if n < 0:
            raise ValueError("No se puede calcular raíz de número negativo.")
        guess = n / 2 if n > 1 else 1
        for _ in range(20):
            guess = (guess + n / guess) / 2
        self.last_result = guess
        return guess

    def factorial(self, n):
        """Calcula n! de forma iterativa."""
        if n < 0:
            raise ValueError("No se puede calcular factorial de número negativo.")
        if int(n) != n:
            raise ValueError("El factorial solo se define para enteros.")
        result = 1
        for i in range(1, int(n) + 1):
            result *= i
        self.last_result = result
        return result

    def clear(self):
        self.last_result = 0

    def get_last_result(self):
        return self.last_result


# =======================
# CLASE FIGURAS GEOMÉTRICAS (Punto 4)
# =======================
class ShapeArea:
    """Clase para calcular áreas de figuras geométricas básicas."""

    def area_square(self, side):
        """Área de un cuadrado: lado^2"""
        if side < 0:
            raise ValueError("El lado no puede ser negativo.")
        return side * side

    def area_rectangle(self, base, height):
        """Área de un rectángulo: base * altura"""
        if base < 0 or height < 0:
            raise ValueError("Las dimensiones no pueden ser negativas.")
        return base * height

    def area_circle(self, radius):
        """Área de un círculo: πr² (usando aproximación de π = 3.1416)"""
        if radius < 0:
            raise ValueError("El radio no puede ser negativo.")
        pi = 3.1416
        return pi * radius * radius

    def area_right_triangle(self, base, height):
        """Área de un triángulo rectángulo: (base * altura) / 2"""
        if base < 0 or height < 0:
            raise ValueError("Las dimensiones no pueden ser negativas.")
        return (base * height) / 2


# =======================
# FUNCIONES AUXILIARES
# =======================
def read_number(prompt):
    """Lee un número flotante o permite regresar."""
    while True:
        entrada = input(prompt).strip()
        if entrada.lower() == "r":
            return None
        try:
            return float(entrada)
        except ValueError:
            print("Entrada inválida. Ingresa un número o 'r' para regresar.")


def read_integer(prompt):
    """Lee un número entero o permite regresar."""
    while True:
        entrada = input(prompt).strip()
        if entrada.lower() == "r":
            return None
        try:
            return int(entrada)
        except ValueError:
            print("Entrada inválida. Ingresa un número entero o 'r' para regresar.")


# =======================
# MENÚ PRINCIPAL
# =======================
def main():
    calc = Calculator()
    shape = ShapeArea()

    while True:
        print("\n=== CALCULADORA OOP AVANZADA ===")
        print("Último resultado:", calc.get_last_result())
        print("1) Operaciones aritméticas básicas y avanzadas")
        print("2) Calcular áreas de figuras geométricas")
        print("3) Limpiar resultado")
        print("4) Salir")

        main_choice = input("Opción (1-4): ").strip()

        # --------------------
        # SUBMENÚ: OPERACIONES
        # --------------------
        if main_choice == "1":
            while True:
                print("\n--- Operaciones Aritméticas ---")
                print("1) Sumar")
                print("2) Restar")
                print("3) Multiplicar")
                print("4) Dividir")
                print("5) Potencia")
                print("6) Raíz cuadrada")
                print("7) Factorial")
                print("8) Regresar al menú principal")

                choice = input("Opción (1-8): ").strip()

                try:
                    if choice == "1":
                        print("\n-- Suma (escribe 'r' para regresar) --")
                        a = read_number("Primer número: ")
                        if a is None:
                            continue
                        b = read_number("Segundo número: ")
                        if b is None:
                            continue
                        print("Resultado:", calc.add(a, b))

                    elif choice == "2":
                        print("\n-- Resta (escribe 'r' para regresar) --")
                        a = read_number("Minuendo: ")
                        if a is None:
                            continue
                        b = read_number("Sustraendo: ")
                        if b is None:
                            continue
                        print("Resultado:", calc.subtract(a, b))

                    elif choice == "3":
                        print("\n-- Multiplicación (escribe 'r' para regresar) --")
                        a = read_number("Primer número: ")
                        if a is None:
                            continue
                        b = read_number("Segundo número: ")
                        if b is None:
                            continue
                        print("Resultado:", calc.multiply(a, b))

                    elif choice == "4":
                        print("\n-- División (escribe 'r' para regresar) --")
                        a = read_number("Dividendo: ")
                        if a is None:
                            continue
                        b = read_number("Divisor: ")
                        if b is None:
                            continue
                        print("Resultado:", calc.divide(a, b))

                    elif choice == "5":
                        print("\n-- Potencia (escribe 'r' para regresar) --")
                        base = read_number("Base: ")
                        if base is None:
                            continue
                        exponent = read_number("Exponente: ")
                        if exponent is None:
                            continue
                        print("Resultado:", calc.power(base, exponent))

                    elif choice == "6":
                        print("\n-- Raíz cuadrada (escribe 'r' para regresar) --")
                        n = read_number("Número: ")
                        if n is None:
                            continue
                        print("Resultado:", calc.square_root(n))

                    elif choice == "7":
                        print("\n-- Factorial (escribe 'r' para regresar) --")
                        n = read_integer("Número entero: ")
                        if n is None:
                            continue
                        print("Resultado:", calc.factorial(n))

                    elif choice == "8":
                        # Regresar al menú principal
                        break

                    else:
                        print("Opción inválida. Ingresa un número entre 1 y 8.")

                except ValueError as e:
                    print("Error:", e)

        # --------------------
        # SUBMENÚ: ÁREAS DE FIGURAS
        # --------------------
        elif main_choice == "2":
            while True:
                print("\n--- Cálculo de Áreas ---")
                print("1) Cuadrado")
                print("2) Rectángulo")
                print("3) Circunferencia")
                print("4) Triángulo rectángulo")
                print("5) Regresar al menú principal")

                area_choice = input("Opción (1-5): ").strip()

                try:
                    if area_choice == "1":
                        print("\n-- Área del cuadrado (escribe 'r' para regresar) --")
                        lado = read_number("Lado: ")
                        if lado is None:
                            continue
                        print("Área:", shape.area_square(lado))

                    elif area_choice == "2":
                        print("\n-- Área del rectángulo (escribe 'r' para regresar) --")
                        base = read_number("Base: ")
                        if base is None:
                            continue
                        altura = read_number("Altura: ")
                        if altura is None:
                            continue
                        print("Área:", shape.area_rectangle(base, altura))

                    elif area_choice == "3":
                        print("\n-- Área de la circunferencia (escribe 'r' para regresar) --")
                        radio = read_number("Radio: ")
                        if radio is None:
                            continue
                        print("Área:", shape.area_circle(radio))

                    elif area_choice == "4":
                        print("\n-- Área del triángulo rectángulo (escribe 'r' para regresar) --")
                        base = read_number("Base: ")
                        if base is None:
                            continue
                        altura = read_number("Altura: ")
                        if altura is None:
                            continue
                        print("Área:", shape.area_right_triangle(base, altura))

                    elif area_choice == "5":
                        break  # regresar al menú principal

                    else:
                        print("Opción inválida. Ingresa un número entre 1 y 5.")

                except ValueError as e:
                    print("Error:", e)

        elif main_choice == "3":
            calc.clear()
            print("Resultado reiniciado a 0.")

        elif main_choice == "4":
            print("Saliendo... ¡Hasta luego!")
            break

        else:
            print("Opción inválida. Intenta de nuevo.")


# =======================
# EJECUCIÓN
# =======================
if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# calculator.py
# Calculadora OOP básica con opción de regresar al menú
# Autor: (tu nombre)
# Ejecutar: python3 calculator.py

class Calculator:
    """Clase que implementa operaciones aritméticas básicas."""
    def __init__(self):
        # Guarda el último resultado calculado
        self.last_result = 0

    def add(self, a, b):
        self.last_result = a + b
        return self.last_result

    def subtract(self, a, b):
        self.last_result = a - b
        return self.last_result

    def multiply(self, a, b):
        self.last_result = a * b
        return self.last_result

    def divide(self, a, b):
        # Control de división por cero
        if b == 0:
            raise ValueError("Error: división por cero.")
        self.last_result = a / b
        return self.last_result

    def clear(self):
        self.last_result = 0

    def get_last_result(self):
        return self.last_result


def read_number(prompt):
    """
    Solicita un número al usuario.
    Si escribe 'r' o 'R', devuelve None para indicar que desea regresar.
    """
    while True:
        entrada = input(prompt).strip()
        if entrada.lower() == "r":
            return None
        try:
            return float(entrada)
        except ValueError:
            print("Entrada inválida. Ingresa un número o 'r' para regresar.")


def main():
    calc = Calculator()

    while True:
        print("\n--- Calculadora OOP básica ---")
        print("Último resultado:", calc.get_last_result())
        print("Elige una operación:")
        print("1) Sumar")
        print("2) Restar")
        print("3) Multiplicar")
        print("4) Dividir")
        print("5) Limpiar resultado")
        print("6) Salir")

        choice = input("Opción (1-6): ").strip()

        # --- SUMA ---
        if choice == "1":
            print("\n-- Suma (escribe 'r' para regresar al menú) --")
            a = read_number("Primer número: ")
            if a is None:  # si el usuario escribió 'r'
                continue
            b = read_number("Segundo número: ")
            if b is None:
                continue
            print("Resultado:", calc.add(a, b))

        # --- RESTA ---
        elif choice == "2":
            print("\n-- Resta (escribe 'r' para regresar al menú) --")
            a = read_number("Minuendo (a): ")
            if a is None:
                continue
            b = read_number("Sustraendo (b): ")
            if b is None:
                continue
            print("Resultado:", calc.subtract(a, b))

        # --- MULTIPLICACIÓN ---
        elif choice == "3":
            print("\n-- Multiplicación (escribe 'r' para regresar al menú) --")
            a = read_number("Primer número: ")
            if a is None:
                continue
            b = read_number("Segundo número: ")
            if b is None:
                continue
            print("Resultado:", calc.multiply(a, b))

        # --- DIVISIÓN ---
        elif choice == "4":
            print("\n-- División (escribe 'r' para regresar al menú) --")
            a = read_number("Dividendo: ")
            if a is None:
                continue
            b = read_number("Divisor: ")
            if b is None:
                continue
            try:
                print("Resultado:", calc.divide(a, b))
            except ValueError as e:
                print(e)

        # --- LIMPIAR ---
        elif choice == "5":
            calc.clear()
            print("Resultado reiniciado a 0.")

        # --- SALIR ---
        elif choice == "6":
            print("Saliendo... ¡Hasta luego!")
            break

        else:
            print("Opción inválida. Intenta de nuevo.")


if __name__ == "__main__":
    main()


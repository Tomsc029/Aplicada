#!/usr/bin/env python3
# calculator.py
# Calculadora OOP avanzada (Punto 3) con opción de regresar al menú
# Autor: (tu nombre)
# Ejecutar: python3 calculator.py

class Calculator:
    """Clase que implementa operaciones aritméticas básicas y avanzadas."""
    def __init__(self):
        # Guarda el último resultado
        self.last_result = 0

    # --- Operaciones básicas ---
    def add(self, a, b):
        self.last_result = a + b
        return self.last_result

    def subtract(self, a, b):
        self.last_result = a - b
        return self.last_result

    def multiply(self, a, b):
        self.last_result = a * b
        return self.last_result

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Error: división por cero.")
        self.last_result = a / b
        return self.last_result

    # --- Operaciones avanzadas (Punto 3) ---
    def power(self, base, exponent):
        """
        Calcula base^exponent sin usar pow() ni math.
        Soporta exponentes negativos.
        """
        result = 1
        if exponent >= 0:
            for _ in range(int(exponent)):
                result *= base
        else:
            for _ in range(abs(int(exponent))):
                result *= base
            result = 1 / result
        self.last_result = result
        return result

    def square_root(self, n):
        """
        Calcula la raíz cuadrada por método de Newton-Raphson.
        No usa math.sqrt().
        """
        if n < 0:
            raise ValueError("No se puede calcular la raíz de un número negativo.")
        guess = n / 2 if n > 1 else 1
        for _ in range(20):  # iteraciones de aproximación
            guess = (guess + n / guess) / 2
        self.last_result = guess
        return guess

    def factorial(self, n):
        """
        Calcula n! de forma iterativa.
        Acepta solo enteros no negativos.
        """
        if n < 0:
            raise ValueError("No se puede calcular factorial de un número negativo.")
        if int(n) != n:
            raise ValueError("El factorial solo se define para enteros.")
        result = 1
        for i in range(1, int(n) + 1):
            result *= i
        self.last_result = result
        return result

    def clear(self):
        self.last_result = 0

    def get_last_result(self):
        return self.last_result


# --- Funciones auxiliares de lectura ---
def read_number(prompt):
    """
    Solicita un número (float).
    Si el usuario escribe 'r', devuelve None para indicar que quiere regresar.
    """
    while True:
        entrada = input(prompt).strip()
        if entrada.lower() == "r":
            return None
        try:
            return float(entrada)
        except ValueError:
            print("Entrada inválida. Ingresa un número o 'r' para regresar.")


def read_integer(prompt):
    """
    Solicita un número entero.
    Si el usuario escribe 'r', devuelve None para indicar que quiere regresar.
    """
    while True:
        entrada = input(prompt).strip()
        if entrada.lower() == "r":
            return None
        try:
            return int(entrada)
        except ValueError:
            print("Entrada inválida. Ingresa un número entero o 'r' para regresar.")


# --- Programa principal ---
def main():
    calc = Calculator()

    while True:
        print("\n--- Calculadora OOP avanzada ---")
        print("Último resultado:", calc.get_last_result())
        print("Elige una operación:")
        print("1) Sumar")
        print("2) Restar")
        print("3) Multiplicar")
        print("4) Dividir")
        print("5) Potencia")
        print("6) Raíz cuadrada")
        print("7) Factorial")
        print("8) Limpiar resultado")
        print("9) Salir")

        choice = input("Opción (1-9): ").strip()

        try:
            # --- Sumar ---
            if choice == "1":
                print("\n-- Suma (escribe 'r' para regresar) --")
                a = read_number("Primer número: ")
                if a is None:
                    continue
                b = read_number("Segundo número: ")
                if b is None:
                    continue
                print("Resultado:", calc.add(a, b))

            # --- Restar ---
            elif choice == "2":
                print("\n-- Resta (escribe 'r' para regresar) --")
                a = read_number("Minuendo (a): ")
                if a is None:
                    continue
                b = read_number("Sustraendo (b): ")
                if b is None:
                    continue
                print("Resultado:", calc.subtract(a, b))

            # --- Multiplicar ---
            elif choice == "3":
                print("\n-- Multiplicación (escribe 'r' para regresar) --")
                a = read_number("Primer número: ")
                if a is None:
                    continue
                b = read_number("Segundo número: ")
                if b is None:
                    continue
                print("Resultado:", calc.multiply(a, b))

            # --- Dividir ---
            elif choice == "4":
                print("\n-- División (escribe 'r' para regresar) --")
                a = read_number("Dividendo: ")
                if a is None:
                    continue
                b = read_number("Divisor: ")
                if b is None:
                    continue
                print("Resultado:", calc.divide(a, b))

            # --- Potencia ---
            elif choice == "5":
                print("\n-- Potencia (escribe 'r' para regresar) --")
                base = read_number("Base: ")
                if base is None:
                    continue
                exponent = read_number("Exponente: ")
                if exponent is None:
                    continue
                print("Resultado:", calc.power(base, exponent))

            # --- Raíz cuadrada ---
            elif choice == "6":
                print("\n-- Raíz cuadrada (escribe 'r' para regresar) --")
                n = read_number("Número: ")
                if n is None:
                    continue
                print("Resultado:", calc.square_root(n))

            # --- Factorial ---
            elif choice == "7":
                print("\n-- Factorial (escribe 'r' para regresar) --")
                n = read_integer("Número entero: ")
                if n is None:
                    continue
                print("Resultado:", calc.factorial(n))

            # --- Limpiar resultado ---
            elif choice == "8":
                calc.clear()
                print("Resultado reiniciado a 0.")

            # --- Salir ---
            elif choice == "9":
                print("Saliendo... ¡Hasta luego!")
                break

            else:
                print("Opción inválida. Ingresa un número entre 1 y 9.")

        except ValueError as e:
            print("Error:", e)


if __name__ == "__main__":
    main()